<?php
	session_start();
	require('include/config.php');

	if (!isset($_SESSION['user']) ||(trim ($_SESSION['user']) == '')){
		header('location:index.php');
	}

	$sql="select * from tbl_users where userid='".$_SESSION['user']."'";
	$query=$conn->query($sql);
	$row=$query->fetch_array();

?>
<?php require("include/template/main-header.php"); ?>
<div class="remain">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Checkout</a></li>
        <li><a href="#">Report</a></li>
        <li><a href="#">Employee</a></li>
		<li><a href="#">CRM</a></li>
		 <li><a href="#">Ecommerce</a></li>
		 <li><a href="#">Profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
	  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> </a></li>
      <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"> <?php echo $row['firstname']; ?><span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Page 1-1</a></li>
            <li><a href="#">Page 1-2</a></li>
            <li><a href="#">Page 1-3</a></li>
          </ul>
        </li>
        
      </ul>
    </div>
  </div>
</nav>
  
<div class="container">
  
  <div class="row">
  <h4>Type of Customers</h4>
  <div class="col-xs-12 col-md-3 ">
  <button type="button" class="btn btn-default rebtn">MEMBER</button> 
  <button type="button" class="btn btn-default rebtn">WALK-IN</button> 
  <br><br>
  <button type="button" class="btn btn-default rebtn_large">4532</button> 
  </div>
		  <div class="col-xs-12 col-md-9 left-bar text-center">
		     <div class="row">
					  <div class="col-xs-6 col-md-3 ">
							 <label>Name</label>
							 <input type="text" class="form-control" ref="firstname" value="<?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?>" >
					  </div>
					  <div class="col-xs-6 col-md-3 ">
						  <label>Phone</label>
							<input type="text" class="form-control" ref="phone" value="<?php echo $row['phone']; ?>" >
					  </div>
					   <div class="col-xs-6 col-md-3 ">
							<label>Email</label>
							<input type="text" class="form-control" ref="email" value="<?php echo $row['firstname']; ?>" >
					  </div>
			  </div>
			   <div class="row">
					  <div class="col-xs-6 col-md-3 ">
							 <label>Total Spent </label>
							 <input type="text" class="form-control" ref="totalspent" value="8000" >
					  </div>
					  <div class="col-xs-6 col-md-3 ">
						  <label>Total Points</label>
							<input type="text" class="form-control" ref="totalpoints" value="602" >
					  </div>
					   <div class="col-xs-6 col-md-3 ">
							<label>Total Visits</label>
							<input type="text" class="form-control" ref="totalvisits" value="30" >
					  </div>
			  </div><div class="row">
					  <div class="col-xs-6 col-md-3 ">
							 <label>Last Visit </label>
							 <input type="date" class="form-control" ref="lastvisit" value="2018-07-22" >
					  </div>
					  <div class="col-xs-6 col-md-3 ">
						  <label>Gift Card Balance</label>
							<input type="text" class="form-control" ref="gcblnc" value="300" >
					  </div>
					   <div class="col-xs-6 col-md-3 ">
							<label>Note</label>
							<input type="text" class="form-control" ref="note" value="View" >
					  </div>
			  </div>
		   </div>
		  
  </div>
   <hr class="style1">
</div>
</div>
</div>

<?php require("include/template/main-footer.php"); ?>
