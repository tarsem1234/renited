<script src="assest/js/vue.js"></script>
<script src="https://unpkg.com/element-ui/lib/index.js"></script>
<script src="assest/js/axios.js"></script>